package tarefa3;

import java.util.Scanner;

public class Tarefa3 {

    public static void main(String[] args) {
        Empregado emp1 = new Empregado();
        
        emp1.setNome("Raul");
        emp1.setSobrenome("Monarin");
        emp1.setSalario(10000);
        emp1.getAumento();
        
        System.out.println(emp1.toString());
        
        
    }
    
}
